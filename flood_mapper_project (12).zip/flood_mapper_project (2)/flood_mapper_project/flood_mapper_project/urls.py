"""flood_mapper_project URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include,re_path
from flood_mapper_APP import views

urlpatterns = [
    path('admin/', admin.site.urls),
    re_path(r'inputs', views.my_form, name='inputs'),
    path('sentinel_data_2021',views.sentinel_data_2021.as_view(),name ='sentinel_data_2021'),

    # re_path(r'contact_us', views, name='contact_us'),
    re_path(r'population_affected',views.population_affected.as_view(),name='population_affected'),
    path('',views.map.as_view(), name='map'),
    path('sentinel_data11',views.sentinel_data11.as_view(),name='sentinel_data11'),
    #  path('analyzededland',views.analyzededland.as_view(),name='analyzededland'),
    #  path('landanalysis889',views.landanalysis889.as_view(),name='landanalysis889'),
    path('model_training',views.model_training.as_view(),name='model_training'),
    path('classification',views.classification.as_view(),name='classification'),
    path('sentinel_data',views.sentinel_data.as_view(),name ='sentinel_data'),
    path('sentinel_data1',views.sentinel_data1.as_view(),name ='sentinel_data1'),
    path('flood_flow',views.flood_flow.as_view(),name='flood_flow'),
    path('floodextend',views.floodextend.as_view(),name ='floodextend'),
    path('home',views.home.as_view(),name ='home'),
    path('studyarea',views.studyarea.as_view(),name ='studyarea'),
    path('floodanalysis',views.floodanalysis.as_view(),name ='floodanalysis'),
    # path('prediction',views.prediction.as_view(),name ='prediction'),
    path('fetchdb',views.fetchdb.as_view(),name ='fetchdb'),
    path('instruction',views.instruction.as_view(),name ='instruction'),
    path('aboutme',views.aboutme.as_view(),name ='aboutme'),
    path('floodstories',views.floodstories.as_view(),name ='floodstories'),
    path('generationchart',views.generationchart.as_view(),name ='generationchart'),
    re_path('population_affected',views.population_affected.as_view(),name='population_affected'),
    path('Draw_AOI',views.Draw_AOI.as_view(),name ='Draw_AOI'),
    path('floodanalysis',views.floodanalysis.as_view(),name ='floodanalysis'),

    re_path(r'prediction', views.prediction, name='prediction'),


    # path('',views.home,name="home"),

   
    # path('', IndexView.as_view(), name='home'),
    # path('get_geo/', get_geo, name='get_geo'),
    # path('upload_shape/', views.upload_shape.as_view(), name='upload-shape'),
    # url(r'^$', views.costView, name='cost')

]

