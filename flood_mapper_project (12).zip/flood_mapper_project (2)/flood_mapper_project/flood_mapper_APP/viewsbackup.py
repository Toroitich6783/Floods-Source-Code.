# My shortcuts>>>>>!!!!
#Maplayout Home page
#Image classification
#Image preprocessing.
# FLOOD FLOW
# Pop-ups
# Send data to database
#Flood prediction model
#Draw_AOI
#Dyanmic world Image Classifcation:
# Land analysis
# Render user inputs
# generationchart for user input data
#Conditional classes

#Importation of variAous Libraries or packages...
from os import path as op
import geemap
import ee
import collections
collections.Callable = collections.abc.Callable
# import geemap.eefolium as geemap
import matplotlib.pyplot as plt


# <<<<End of new imports
from fileinput import filename
from django.shortcuts import redirect, render
from django.http import HttpResponse
import warnings
import numpy as np


from requests import request 
warnings.filterwarnings('ignore')
# Create your views here.
from telnetlib import AO
from django.shortcuts import render

from matplotlib.pyplot import cla, draw, figure


import collections
collections.Callable = collections.abc.Callable

# Create your views here.
import folium
from django.views.generic import TemplateView 
import geemap
import geemap.foliumap as geemap
import ipyleaflet 
import ee 
import geopandas as gdp
import pandas as pd
from geemap import Map

#connection to DATABASE
import psycopg2 as ps
import psycopg2
from folium import plugins
from folium.plugins import Draw
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
#sending emails
from django.core.mail import send_mail
from sklearn import metrics
import numpy as np

import pandas as pd
import folium
import os
import base64
from folium import IFrame

# import geemap.eefolium as geemap

##############################
class landanalysis889(TemplateView):
        template_name = 'index.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
                        location=[0.5327408978908402, 36.12095065065061],
                        zoom_start=13,
                        # plugin_Draw = false, 
        #     Draw_export = True
        )
                Map.add_basemap(basemap='HYBRID')
               #mouse position
                fmtr = "function(num) {return L.Util.formatNum(num, 3) + ' º ';};"
                plugins.MousePosition(position='topleft', separator=' | ', prefix="Mouse:",lat_formatter=fmtr, lng_formatter=fmtr).add_to(Map)

                
                global muringato
                muringato = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
                # Map.addLayer(muringato,{},"Test",false)
        
                Map.center_object(muringato,13);
                start_date="2020-01-01"#Set start_date(yy/mon/day)
                end_date="2020-07-31"#Set End_date(yy/mon/day)
                season = ee.Filter.date(start_date,end_date);#Filter image based on the time frame(start_date and end_date
                
                global sentinel_image
                sentinel_1= ee.ImageCollection('COPERNICUS/S1_GRD');
                sCollection=sentinel_1\
                        .filterBounds(muringato) \
                                .filter(season) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV')) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH')) \
                    .filter(ee.Filter.eq('instrumentMode', 'IW'))
              
                desc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
                asc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));

                global composite
                composite = ee.Image.cat([
                asc.select('VH').mean(),
                asc.select('VV').mean(),
                desc.select('VH').mean()
                ]).focal_median();
   
 #-------------SENTINEL_2A DATA----------------------#  
                global sentinel_2A
                sentinel_2A = ee.ImageCollection('COPERNICUS/S2')\
               .filterBounds(muringato)\
               .filterDate("2020-01-01","2020-03-31")\
               .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",10))\
               .median()\
               .select('B1','B2', 'B3', 'B4', 'B5', 'B6', 'B7','B8', 'B10', 'B11')\
               .clip(muringato)
                
                sentinel_2Avispar={"min":0, "max":2500,"bands": ['B4','B3','B2']}#Visualization parameters used.

                Map.addLayer(sentinel_2A,sentinel_2Avispar,"sentinel 2A")
                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"landanalysis889": figure}

#####################################
########Map layout set up!!!!!!#####
###################################
#MapLayout
class map(TemplateView):
        template_name = 'index.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            # plugin_Draw = True, 
        #     Draw_export = True
        )
                Map.add_to(figure)
                Map.set_center(33.5240928719809
,1.391422765095509,9)
        
                style = {'color': '131313', 'fillColor':' FD0505'}
                
                # plugins.Draw(export=True, filename='Export_AOI_II.shp',position='topleft').add_to(Map)  

                basemaps = {
                 'Google Maps': folium.TileLayer(
        tiles = 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
        attr = 'Google',
        name = 'Google Maps',
        overlay = False,
        control = True
    ),
            'Esri Satellite': folium.TileLayer(
        tiles = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attr = 'Esri',
        name = 'Esri Satellite',
        overlay = True,
        control = True
    ),'Google Satellite Hybrid': folium.TileLayer(
        tiles = 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}',
        attr = 'Google',
        name = 'Google Satellite',
        overlay = False,
        control = True
    ),
                          
                          }
                        
                basemaps['Google Satellite Hybrid'].add_to(Map)

                basemaps['Esri Satellite'].add_to(Map)
                legend_dict = {
    'Flooded Region':'#2669d6',
    'Vegetation': '33698b',#
    
                }
                Map.add_legend(legend_dict=legend_dict,position='topleft')
                
                

#Land analysis>>>Start
                df= pd.read_csv(r"D:\@StarksIndustries\bikes git\Django-GEE\gee\Overall Data.csv")

                data=df      
                width, height, fat_wh = 130, 10, 1.2
                info=f"""
      <p style="font-size: 20px;font-weight: bold;"><u>Land Analysis:</u></p>
        </>Chart📊:Analysis</p>

     
       <img src="https://codeinghtml.w3spaces.com/imgaes/charts.jpg">
<p>The charts shown above gives a clear depiction on how various individuals land activities<br> with the selected area of intrest is likely to be affected incase of the a continuous water rise<br> within the the selected area of intrest...</p>

        </p>

        """
                iframe = IFrame(width=width*fat_wh, height=height*fat_wh)
                popup  = folium.Popup(iframe, parse_html = True, max_width=1500)
                folium.Marker(location=[0.523136608594865,36.10552813530029],tooltip=info,  icon=folium.Icon(), 
                popup=popup).add_to(Map)
#Land analysis>>>end..

                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"map": figure}

##########################################################
#############Flood prediction model#######################
##########################################################
class model_training(TemplateView):
        template_name = 'model_training.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[0.5327408978908402, 36.12095065065061],
            zoom_start=13,
        #     plugin_Draw = True
        #     Draw_export = True
        )
                
                
                Map.add_to(figure)
                keserian = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
                Map.addLayer(keserian,{},"Keserian")
                
         
# Connection to postgres(personal_database)
                global connection
                connection=ps.connect(dbname="postgres",#Database_name
                 user="postgres",#Database user name
                 password="Mosong6783",##Database_passcode.
                 host="localhost",#Database host
                 port="5432"##Db operational port
                )
                global cursor
                cursor=connection.cursor()

                sql_query1="""SELECT * FROM "flood_mapper_APP_floodreader1" WHERE Id=(SELECT max(Id) FROM "flood_mapper_APP_floodreader1");"""
                cursor.execute(sql_query1)
                data=cursor.fetchall()
                
                
                
# weather Station from Django user inputs:Row 1
                for Station_row in data:
                    ("weather_stattion=",Station_row[1])
                inputs_station=Station_row[1]
#Temperature Readings from Django user Inputs:Row 2
                for Temperature_row in data:#Condition for to select first row of data: containing Tempearture readings
                    ("Temperature=",Temperature_row[3])
                Temperaturereading=Temperature_row[3]
#Rainfall Readings from Django user inputs:Row 3
                for Rainfall_Amount_row in data:
                    ("Rainfall=",Rainfall_Amount_row[4])
                Rainfall_input=Rainfall_Amount_row[4]

##time Readings from Django user Inputs:Row 4 
                for time_row in data:
                    ("Time=",time_row[5])
                Timeinput=time_row[5]

                for soil_moisture in data:
                    ("Time=",soil_moisture[6])
                soil_moisture_input=soil_moisture[6]

                for Evaporation in data:
                    ("Time=",Evaporation[7])
                Evaporation_input=Evaporation[7]

                print("WeatherStation_2:",inputs_station)
                print("Temperaturereading_3:",Temperaturereading)
                print("Rainfall_Amount_4:",Rainfall_input)
                print("Time inputs_5:",Timeinput)
                print("soil_moisture_input_6:",soil_moisture_input)
                print("soil_moisture_input_7:",Evaporation_input)


# # weather Station from Django user inputs:Row 1
#                 for Station_row in data:
#                         ("Rainfall=",Station_row[1])
#                         inputs_station=Station_row[1]
# #Rainfall Readings from Django user inputs:Row 3
#                 for Rainfall_Amount_row in data:
#                         ("Rainfall=",Rainfall_Amount_row[3])
#                         global Rainfall_Amount1
#                         Rainfall_Amount1=Rainfall_Amount_row[3]

# #Temperature Readings from Django user Inputs:Row 2
#                 for Temperature_row in data:#Condition for to select first row of data: containing Tempearture readings
#                         ("Temperature=",Temperature_row[2])
#                         Temperaturereading=Temperature_row[2]
# ##Temperature Readings from Django user Inputs:Row 4 
#                 for time_row in data:
#                         ("Time=",time_row[4])
#                         Timeinput=time_row[4]

#                 print("WeatherStation:",inputs_station)
#                 print("Temperaturereading:",Temperaturereading)
#                 print("Rainfall_Amount:",Rainfall_Amount1)
#                 print("Time inputs:",Timeinput)
                global Rainfall_Amount1
                Rainfall_Amount1=Rainfall_input
# data

                
                
                global db_connection
                db_connection =ps.connect(dbname="KSA",#Database_name.
                 user="postgres",#Database_user.
                 password="Mosong6783",#Database_passcode.
                 host="localhost",#Db Host
                 port="5432"#Db operational port
                )
                ###General code combination
                # global temperature
                temperature=pd.read_csv("Temperaturerainfall.csv")
                global temperaturerainfall
                temperaturerainfall=temperature.drop(columns=["location","address","longitude","latitude","state","Time"])


#iloc function to select a rows
#Assigning the selected rows axis eg x and y axis.
                x_temperaturerainfall=temperaturerainfall.iloc[:,:1].values
                y_temperaturerainfall=temperaturerainfall.iloc[:,1:2].values


#splitting data
#80% training and 20% validation
#Aspect of Random With random_state=None , we get different train and test sets across different executions and the shuffling
# process is out of control. With random_state=0 , we get the same train and test sets across different executions.
                from sklearn.model_selection import train_test_split
                x_train_temp_rain, x_test_temp_rain,y_train_temp_rain, y_tes_temp_raint = train_test_split(x_temperaturerainfall,y_temperaturerainfall,test_size=0.3,random_state=0)
                
                from sklearn.linear_model import LinearRegression
# statistical way of measuring the relationship between one or more independent variables vs one dependent variable. 
                global regressor_temp_rainfall
                regressor_temp_rainfall = LinearRegression()
                regressor_temp_rainfall.fit(x_train_temp_rain,y_train_temp_rain)

                y_pred_temp_rain= regressor_temp_rainfall.predict(x_test_temp_rain)
# print(y_pred_temp_rain)

#Reshaping a 1D array to a 2D array i.e array [[]]
                input_temp=(np.array(Temperaturereading).reshape(1,-1))
                usertemp88=input_temp
                global predicted_rainfall
                predicted_rainfall=regressor_temp_rainfall.predict(usertemp88)
                print("Expected Rainfall will be(mm):",predicted_rainfall)
                # elif a==input_temp:
                #         predicted_rainfall=regressor.predict(directreadings)
                #         print("Expected Rainfall will be(mm):",predicted_rainfall)
#Read rainfall data

#Rainfall Vs Water Level 
                rainfall_water_level=pd.read_csv("Rainfall_Data.csv")# define data
                climatic_drop=rainfall_water_level.drop(columns=["system:time_start"])
#Assigning the selected rows axis eg x and y axis.
                x_climatic_df=climatic_drop.iloc[:,:1].values
                y_climatic_df=climatic_drop.iloc[:,1:2].values
   
                from sklearn.model_selection import train_test_split
                x_train_climatic, x_test_climatic,y_train_climatic, y_test_climatic= train_test_split(x_climatic_df,y_climatic_df,test_size=0.1,random_state=0)
               
                from sklearn.linear_model import LinearRegression
# statistical way of measuring the relationship between one or more independent variables vs one dependent variable. 
                global rain_level_regressor
                rain_level_regressor = LinearRegression()
                rain_level_regressor.fit(x_train_climatic,y_train_climatic)
                y_pred_water_level= rain_level_regressor.predict(x_test_climatic)
                
                #Reshaping a 1D array to a 2D array i.e array [[]]
                User_Rainfall_Amount=(np.array(Rainfall_Amount1).reshape(1,-1))
             
                temp=(np.array(Temperaturereading).reshape(1,-1))

#Predict next water level 
#Input === Rainfall
                Rainfall_Input=[[136.604]] #Testing dummies data to act as an input

                predicted_water_level_input=rain_level_regressor.predict(User_Rainfall_Amount)

#Conversion of a 2D to 3D----Reshaping
                x=predicted_water_level_input[0]
                predicted_water_level_input=x[0]
# Round off to-4 figure
                global predicted_water_level_value
                predicted_water_level_value=(round(predicted_water_level_input, 4))
                print("Expected water rise will be(Meters) based on userinput:",predicted_water_level_value)
                
                # predicted_water_level_input1=[[1200]]
                predicted_water_level=predicted_water_level_input
# x=predicted_water_level[0]
# predicted_water_level_DB=x[0]

# predicted_water_level_DB
                predicted_water_level_DB=(round(predicted_water_level, 4))
                
#    <----------END OF RAINFALL MODEL>

# #New send data to database!!!
#Conditional statement:
#Weather station 1
                inputs_station_1=int(inputs_station)
                station_name1="station_19"
                station_name2="Komilo"
                station_name3="Torongo"
                station_name4="Loiminage"
                station_name5="Tugumoi"
                station_name6="Dekut_Farm"
                station_name7="Nyeri_Town"


                if inputs_station_1 == 1:
                        try:
                                connection=ps.connect(dbname="KSA",#Database_name
                                                      user="postgres",#Database user name
                 password="Mosong6783",##Database_passcode.
                 host="localhost",#Database host
                 port="5432"##Db operational port
                )
                                cursor = connection.cursor()

                                postgres_insert_query = """ INSERT INTO rainfall("state","location","latitude","longitude","time","rainfall","predicted_water_level","station_name","temperature","soil_moisture","Evaporation" ) 
                                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                                record_to_insert = ('kiserian', 'Keserian',0.523136608594865,36.10552813530029,Timeinput,Rainfall_input,predicted_water_level_DB,inputs_station,Temperaturereading,soil_moisture_input,Evaporation_input)
                                cursor.execute(postgres_insert_query, record_to_insert)

                                connection.commit()
                                count = cursor.rowcount
                                print("successfully send current data readings to Database:#Weather station 1")
                        except (Exception, psycopg2.Error) as error:
                                print("Failed to send final reading", error)

#Weather station 2
                elif inputs_station_1 == 2:
                        try:
                                connection=ps.connect(dbname="KSA",#Database_name
                 user="postgres",#Database user name
                 password="Mosong6783",##Database_passcode.
                 host="localhost",#Database host
                 port="5432"##Db operational port
                )
                                cursor = connection.cursor()

                                postgres_insert_query = """ INSERT INTO rainfall("state","location","latitude","longitude","time","rainfall","predicted_water_level","station_name","temperature","soil_moisture","Evaporation" ) 
                                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                                record_to_insert = ('kiserian', 'Keserian',0.523136608594865,36.10552813530029,Timeinput,Rainfall_input,predicted_water_level_DB,inputs_station,Temperaturereading,soil_moisture_input,Evaporation_input)
                                cursor.execute(postgres_insert_query, record_to_insert)

                                connection.commit()
                                count = cursor.rowcount
                                print("successfully send current data readings to rainfall Database:#Weather station 2")
                        except (Exception, psycopg2.Error) as error:
                                print("Failed to send final reading", error)
#Weather station 3
                elif inputs_station_1 == 3:
                        try:
                                connection=ps.connect(dbname="KSA",#Database_name
                 user="postgres",#Database user name
                 password="Mosong6783",##Database_passcode.
                 host="localhost",#Database host
                 port="5432"##Db operational port
                )
                                cursor = connection.cursor()
                                postgres_insert_query = """ INSERT INTO rainfall("state","location","latitude","longitude","time","rainfall","predicted_water_level","station_name","temperature","soil_moisture","Evaporation" ) 
                                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                                record_to_insert = ('kiserian', 'Keserian',0.523136608594865,36.10552813530029,Timeinput,Rainfall_input,predicted_water_level_DB,inputs_station,Temperaturereading,soil_moisture_input,Evaporation_input)
                                cursor.execute(postgres_insert_query, record_to_insert)

                                connection.commit()
                                count = cursor.rowcount
                                print("successfully send current readings to Database:#Weather station 3")
                        except (Exception, psycopg2.Error) as error:
                                print("Failed to send final reading", error)
#Weather station 4
                elif inputs_station_1 == 4:
                        try:
                                postgres_insert_query = """ INSERT INTO rainfall("state","location","latitude","longitude","time","rainfall","predicted_water_level","station_name","temperature","soil_moisture","Evaporation" ) 
                                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                                record_to_insert = ('kiserian', 'Keserian',0.523136608594865,36.10552813530029,Timeinput,Rainfall_input,predicted_water_level_DB,inputs_station,Temperaturereading,soil_moisture_input,Evaporation_input)
                                cursor.execute(postgres_insert_query, record_to_insert)

                                connection.commit()
                                count = cursor.rowcount
                                print("successfully send current readings to Database:#Weather station 4")
                        except (Exception, psycopg2.Error) as error:
                                print("Failed to send final reading", error)
#Weather station 5
                elif inputs_station_1 == 5:
                        try:
                                connection=ps.connect(dbname="KSA",#Database_name
                 user="postgres",#Database user name
                 password="Mosong6783",##Database_passcode.
                 host="localhost",#Database host
                 port="5432"##Db operational port
                )
                                cursor = connection.cursor()

                                postgres_insert_query = """ INSERT INTO rainfall("state","location","latitude","longitude","time","rainfall","predicted_water_level","station_name","temperature","soil_moisture","Evaporation" ) 
                                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                                record_to_insert = ('kiserian', 'Keserian',0.523136608594865,36.10552813530029,Timeinput,Rainfall_input,predicted_water_level_DB,inputs_station,Temperaturereading,soil_moisture_input,Evaporation_input)
                                cursor.execute(postgres_insert_query, record_to_insert)

                                connection.commit()
                                count = cursor.rowcount
                                print("successfully send current readings to Database:#Weather station 5 ")
                        except (Exception, psycopg2.Error) as error:
                                print("Failed to send final reading", error)
#Weather station 6
                elif inputs_station_1 == 6:
                        try:
                                connection=ps.connect(dbname="KSA",#Database_name
                 user="postgres",#Database user name
                 password="Mosong6783",##Database_passcode.
                 host="localhost",#Database host
                 port="5432"##Db operational port
                )
                                cursor = connection.cursor()

                                postgres_insert_query = """ INSERT INTO rainfall("state","location","latitude","longitude","time","rainfall","predicted_water_level","station_name","temperature","soil_moisture","Evaporation" ) 
                                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                                record_to_insert = ('kiserian', 'Keserian',0.523136608594865,36.10552813530029,Timeinput,Rainfall_input,predicted_water_level_DB,inputs_station,Temperaturereading,soil_moisture_input,Evaporation_input)
                                cursor.execute(postgres_insert_query, record_to_insert)

                                connection.commit()
                                count = cursor.rowcount
                                print("successfully send current readings to Database:#Weather station 6 ")
                        except (Exception, psycopg2.Error) as error:
                                print("Failed to send final reading", error)
#Weather station 7
                elif inputs_station_1 == 7:
                        try:
                                connection=ps.connect(dbname="KSA",#Database_name
                 user="postgres",#Database user name
                 password="Mosong6783",##Database_passcode.
                 host="localhost",#Database host
                 port="5432"##Db operational port
                )
                                cursor = connection.cursor()

                                postgres_insert_query = """ INSERT INTO rainfall("state","location","latitude","longitude","time","rainfall","predicted_water_level","station_name","temperature","soil_moisture","Evaporation" ) 
                                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                                record_to_insert = ('kiserian', 'Keserian',0.523136608594865,36.10552813530029,Timeinput,Rainfall_input,predicted_water_level_DB,inputs_station,Temperaturereading,soil_moisture_input,Evaporation_input)
                                cursor.execute(postgres_insert_query, record_to_insert)

                                connection.commit()
                                count = cursor.rowcount
                                print("successfully send current readings to Database:#Weather station 7 ")
                        except (Exception, psycopg2.Error) as error:
                                print("Failed to send final reading", error)
                else:
                        print ("Error reloaded!!!")

# End of sendinding data to database!!
# Reading Realtime Data
                global sql
                sql ="""select*FROM rainfall
         """
                gdf = geemap.read_postgis(sql, db_connection)
        #Select the last readings(Last column)
        #condition maximum gid value
                lastgid="""SELECT * FROM rainfall WHERE gid=(SELECT max(gid) FROM rainfall);"""
        #Reading data from database
                global gdf1
                gdf1 = geemap.read_postgis(lastgid, db_connection)

#SELECTION OF USERINPUTS
                       #Select the last readings(Last column)
        #condition maximum gid value
                lastgid_userinputs="""SELECT * FROM FLOOD_MAPPER_APPII_Readings WHERE gid=(SELECT max(gid) FROM rainfall);"""
        #Reading data from database
                global Userinputs_gdf
                Userinputs_gdf = geemap.read_postgis(lastgid, db_connection)#Crop_mapping data based on connection to KSA DB

                
                
#####################################
############Pop-ups ###########
#####################################
                predicted_riverlevel=predicted_water_level_input
                
                alert_pop_up=Userinputs_gdf.drop(columns=["state","geom","gid","weather_station"])
                print(alert_pop_up,"alert_pop_up")
            

                # add marker one by one on the map
                for i in range(0,len(gdf1)):
                    html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                iframe = folium.IFrame(html=html, width=200, height=200)
                popup = folium.Popup(iframe, max_width=2650)
                folium.Marker(
                    location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                    popup=popup,
                    icon=folium.Icon(color="blue", icon="info-sign"),
                 ).add_to(Map)
                
                
                
                
                # if predicted_riverlevel > 1.0:
                #         Map.add_points_from_xy(alert_pop_up,x="longitude",y="latitude",layer_name='Weather Station',marker_colors=['yellow'],icon_colors=['yellow'])
                #         # Map.add_circle_markers_from_xy(alert_pop_up, x="longitude", y="latitude", radius=15, color="red", fill_color="black")

                # else:
                #         Map.add_points_from_xy(alert_pop_up,x="longitude",y="latitude",layer_name='Weather Station',marker_colors=['yellow'],icon_colors=['yellow'])
               
               
               #######################################################3
                        
                        
# print("Expected water rise will be(Meters)",predicted_riverlevel)

                

                
        # weather_data=pd.read_csv("Weather.csv")
    
                # Map.add_points_from_xy(alert_pop_up,x="longitude",y="latitude",layer_name='Weather Station',marker_colors=['yellow'],icon_colors=['yellow'])
   
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"model_training": figure}

# #################################################
# ################# FLOOD FLOW ####################
# #################################################
class flood_flow(TemplateView):
        template_name = "flood_flow.html"
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
                location=[0.5327408978908402, 36.12095065065061],
                zoom_start=13,
                plugin_Draw = True
        #     Draw_export = True
         )
                Map.add_to(figure)
                kiserian = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")

        #Extraction of Perment water from Global Surface Water(GSW)
                blue_palette = ['0000FF']
                jrcGSW = ee.Image("JRC/GSW1_2/GlobalSurfaceWater")
                waterBodies = jrcGSW.select('occurrence').clip(kiserian)
                vis_waterBodies = {min:0, max:100, "palette": blue_palette}
          
                Map.addLayer(**{
    # mask waterBodies so as to not detect flood in the waterBodies.
    # .divide(100) causes the opacity/transparency of the pixels to
    # be set based on the waterBodies occurrence value.
    
        'ee_object': waterBodies.updateMask(waterBodies.divide(100)),\
        'name': "Permanent water bodies (BLUE)", \
        'vis_params': vis_waterBodies})
                Map.addLayer( waterBodies.updateMask(waterBodies.divide(100)),vis_waterBodies,"Permanent water bodies (BLUE)")
# Map
    
# Set the map and base and associted features
# Map.setOptions('TERRAIN')
# Map.centerObject(kiserian, 8)

# Create an empty image into which to paint the features, cast to byte.
                empty = ee.Image().byte()
                slope_palette88 = ['ff0000']

# Paint both the fill and the edges.
                filledOutlines = empty.paint(kiserian, 'BIOME_NUM').paint(kiserian, 0, 2)
                # Map.addLayer(filledOutlines, {"palette": slope_palette88, max: 14}, 'ROI')
# Map
#Set the time stand
                beforeStart = '2019-03-13'
                beforeEnd = '2019-06-27'

                afterStart = '2019-08-21'
                afterEnd = '2019-10-16'
        
                s1 = ee.ImageCollection("COPERNICUS/S1_GRD")

                s1Collection = s1.filter(ee.Filter.eq('instrumentMode', 'IW'))\
                      .filter(ee.Filter.eq('transmitterReceiverPolarisation', ['VV','VH'])) \
                      .filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'))\
                      .filter(ee.Filter.eq('resolution_meters',10)) \
                      .filterBounds(kiserian) \
                      .select('V.*')
                before_collection = s1Collection.select('VH').filterDate(beforeStart, beforeEnd)
                after_collection = s1Collection.select('VH').filterDate(afterStart, afterEnd)

                before = before_collection.mosaic().clip(kiserian)
                after = after_collection.mosaic().clip(kiserian)
                #Refined Lee Method!!!!
# Function to convert from dB
        
                def toNatural(img):
                        return ee.Image(10.0).pow(img.select(0).divide(10.0))

# Function to convert to dB
                def toDB(img):
                        return ee.Image(img).log10().multiply(10.0)

                def RefinedLee(img):
                        
    # img must be in natural units, i.e. not in dB!
    # Set up 3x3 kernels 
                        weights3 = ee.List.repeat(ee.List.repeat(1,3),3)
                        kernel3 = ee.Kernel.fixed(3,3, weights3, 1, 1, False)
    
                        mean3 = img.reduceNeighborhood(ee.Reducer.mean(), kernel3)
                        variance3 = img.reduceNeighborhood(ee.Reducer.variance(), kernel3)

    # Use a sample of the 3x3 windows inside a 7x7 windows to determine gradients and directions
                        sample_weights = ee.List([[0,0,0,0,0,0,0], [0,1,0,1,0,1,0],\
                             [0,0,0,0,0,0,0], [0,1,0,1,0,1,0], \
                             [0,0,0,0,0,0,0], [0,1,0,1,0,1,0],[0,0,0,0,0,0,0]])

                        sample_kernel = ee.Kernel.fixed(7,7, sample_weights, 3,3, False)

    # Calculate mean and variance for the sampled windows and store as 9 bands
                        sample_mean = mean3.neighborhoodToBands(sample_kernel)
                        sample_var = variance3.neighborhoodToBands(sample_kernel)

    # Determine the 4 gradients for the sampled windows
                        gradients = sample_mean.select(1).subtract(sample_mean.select(7)).abs()
                        gradients = gradients.addBands(sample_mean.select(6).subtract(sample_mean.select(2)).abs())
                        gradients = gradients.addBands(sample_mean.select(3).subtract(sample_mean.select(5)).abs())
                        gradients = gradients.addBands(sample_mean.select(0).subtract(sample_mean.select(8)).abs())

    # And find the maximum gradient amongst gradient bands
                        max_gradient = gradients.reduce(ee.Reducer.max())

    # Create a mask for band pixels that are the maximum gradient
                        gradmask = gradients.eq(max_gradient)

    # duplicate gradmask bands: each gradient represents 2 directions
                        gradmask = gradmask.addBands(gradmask)

    # Determine the 8 directions
                        directions = sample_mean.select(1) \
                            .subtract(sample_mean.select(4)) \
                            .gt(sample_mean.select(4).subtract(sample_mean.select(7))) \
                            .multiply(1)
                        directions = directions.addBands(sample_mean.select(6).subtract(sample_mean.select(4)) \
                           .gt(sample_mean.select(4).subtract(sample_mean.select(2))) \
                           .multiply(2))
                        directions = directions.addBands(sample_mean.select(3).subtract(sample_mean.select(4)) \
                           .gt(sample_mean.select(4).subtract(sample_mean.select(5))) \
                           .multiply(3))
                        directions = directions.addBands(sample_mean.select(0).subtract(sample_mean.select(4)) \
                           .gt(sample_mean.select(4).subtract(sample_mean.select(8))) \
                           .multiply(4))
    # The next 4 are the not() of the previous 4
                        directions = directions.addBands(directions.select(0).Not().multiply(5))
                        directions = directions.addBands(directions.select(1).Not().multiply(6))
                        directions = directions.addBands(directions.select(2).Not().multiply(7))
                        directions = directions.addBands(directions.select(3).Not().multiply(8))

    # Mask all values that are not 1-8
                        directions = directions.updateMask(gradmask)

    # "collapse" the stack into a singe band image (due to masking, each pixel has just 
    # one value (1-8) in it's directional band, and is otherwise masked)
                        directions = directions.reduce(ee.Reducer.sum()) 

                        pal = ['ffffff','ff0000','ffff00', '00ff00', '00ffff', '0000ff', 'ff00ff', '000000']
#     Map.addLayer(directions.reduce(ee.Reducer.sum()), {min:1, max:8, palette: pal}, 'Directions', false)

                        sample_stats = sample_var.divide(sample_mean.multiply(sample_mean))

    # Calculate localNoiseVariance
                        sigmaV = sample_stats.toArray().arraySort().arraySlice(0,0,5).arrayReduce(ee.Reducer.mean(), [0])

    # Set up the 7*7 kernels for directional statistics
                        rect_weights = ee.List.repeat(ee.List.repeat(0,7),3).cat(ee.List.repeat(ee.List.repeat(1,7),4))

                        diag_weights = ee.List([[1,0,0,0,0,0,0], [1,1,0,0,0,0,0],\
                                [1,1,1,0,0,0,0], [1,1,1,1,0,0,0], \
                                [1,1,1,1,1,0,0], [1,1,1,1,1,1,0], [1,1,1,1,1,1,1]])

                        rect_kernel = ee.Kernel.fixed(7,7, rect_weights, 3, 3, False)
                        diag_kernel = ee.Kernel.fixed(7,7, diag_weights, 3, 3, False)

    # Create stacks for mean and variance using the original kernels. Mask with relevant direction.
                        dir_mean = img.reduceNeighborhood(ee.Reducer.mean(), rect_kernel).updateMask(directions.eq(1))
                        dir_var = img.reduceNeighborhood(ee.Reducer.variance(), rect_kernel).updateMask(directions.eq(1))

                        dir_mean = dir_mean.addBands(img.reduceNeighborhood(ee.Reducer.mean(), diag_kernel).updateMask(directions.eq(2)))
                        dir_var = dir_var.addBands(img.reduceNeighborhood(ee.Reducer.variance(), diag_kernel).updateMask(directions.eq(2)))

    # and add the bands for rotated kernels
    #for  (var i=1; i<4; i++):
                        for i in range(1, 4):
                                dir_mean = dir_mean.addBands(img.reduceNeighborhood(ee.Reducer.mean(), rect_kernel.rotate(i)) \
                                        .updateMask(directions.eq(2*i+1)))
                                dir_var = dir_var.addBands(img.reduceNeighborhood(ee.Reducer.variance(), rect_kernel.rotate(i)) \
                                        .updateMask(directions.eq(2*i+1)))
                                dir_mean = dir_mean.addBands(img.reduceNeighborhood(ee.Reducer.mean(), diag_kernel.rotate(i)) \
                                        .updateMask(directions.eq(2*i+2)))
                                dir_var = dir_var.addBands(img.reduceNeighborhood(ee.Reducer.variance(), diag_kernel.rotate(i)) \
                                        .updateMask(directions.eq(2*i+2)))  

    # "collapse" the stack into a single band image (due to masking, each pixel has just one value in it's directional band, and is otherwise masked)
                        dir_mean = dir_mean.reduce(ee.Reducer.sum())
                        dir_var = dir_var.reduce(ee.Reducer.sum())

    # A finally generate the filtered value
                        varX = dir_var.subtract(dir_mean.multiply(dir_mean).multiply(sigmaV)).divide(sigmaV.add(1.0))

                        b = varX.divide(dir_var)

                        result = dir_mean.add(b.multiply(img.subtract(dir_mean)))
    
                        return(result.arrayFlatten([['sum']]))

# Get before-flood and after-flood Refined Lee filtered images
                before_rLee = ee.Image(toDB(RefinedLee(toNatural(before))))
                after_rLee = ee.Image(toDB(RefinedLee(toNatural(after))))
# Get before-flood and after-flood Refined Lee filtered images

                difference_rLee = after_rLee.divide(before_rLee)

                DIFF_UPPER_THRESHOLD = 1.25

# Identify pixels above the threshold (i.e flood pixels).
# Set all other pixels to 0
                floodMask = difference_rLee.gt(DIFF_UPPER_THRESHOLD).rename('water') 

# Keep only the flood pixels. Remove all pixels equal to 0
                floodedAreas = floodMask.selfMask()
        
# Include JRC layer on surface water seasonality and occurrence to mask flood pixels from areas of "permanent" water, i.e., where there is water > 10 months of the year

                jrcGSW = ee.Image("JRC/GSW1_2/GlobalSurfaceWater")
                waterBodies = jrcGSW.select('occurrence').clip(kiserian)
                vis_waterBodies = {min:0, max:100, "palette": slope_palette88}
          
                Map.addLayer(**{
    # mask waterBodies so as to not detect flood in the waterBodies.
    # .divide(100) causes the opacity/transparency of the pixels to
    # be set based on the waterBodies occurrence value.
    
    'ee_object': waterBodies.updateMask(waterBodies.divide(100)),\
    'name': "Permanent water bodies (BLUE)", \
    'vis_params': vis_waterBodies})
# Set a mask = 1 if water > 10 months of the year, i.e permanent water pixels Non-permanent water (flood) pixels = 0 Remove flood pixels Identify flooded areas that are a minimum 0.25 ha (>= 3 pixels)connectedPixelCount() to get a contiguous area

                seasonality = jrcGSW.select('seasonality')
        
                permWater = seasonality.gte(10).selfMask()
  
# In the floodedAreas layer, assign all permanent water pixels = 0
                permWater_removed = floodedAreas.where(permWater,0)
  
# Remove all the permanent water present in the flooded layer.
# floodedAreas layer has only flood pixels
                onlyFlooded = floodedAreas.updateMask(permWater_removed).selfMask()
 
# Set minimum flood area in pixels = 3, approximately 0.25 ha
                minFloodPixels = ee.Number(3)
  
# Scale the results to display on the map. 
# Reprojecting with a specified scale ensures that the pixel area 
# does not change with zoom.
                prj = jrcGSW.projection()
                scale = prj.nominalScale()
                contFloodArea = onlyFlooded.connectedPixelCount(25) \
                      .reproject(prj.atScale(scale))
                      
# Apply the minimum area requirement.
                minFloodArea = contFloodArea.gte(minFloodPixels).selfMask() \
                    .reproject(prj.atScale(scale))
# Mask out areas with more than 5 percent slope using the DEM HydroSHEDS (computing gradients requires a fixed projection)

                demHydroSHEDS = ee.Image("WWF/HydroSHEDS/03VFDEM")
                terrain = ee.Algorithms.Terrain(demHydroSHEDS)
                slope = terrain.select('slope')
                finalFloodedArea = minFloodArea.updateMask(slope.lt(5))

                slope_palette1 = ['0C7600','4CE500','B2FF18','FFFF00','FFAE00','ff6d66','FF0000']
        
                after_filter = ee.Image(toDB(RefinedLee(toNatural(after))))
                before_filter = ee.Image(toDB(RefinedLee(toNatural(before))))
                            
# Display the flooded areas
                # Map.addLayer(before_filter.clip(kiserian),{'min':-25, 'max':0}, 'Before Filtering',False);
                # Map.addLayer(after_filter.clip(kiserian), {'min':-25, 'max':0}, 'After Filtering',False);
       

#Dyamic world 2  
                global start_date
                start_date="2020-01-01"#Set start_date(yy/mon/day)
                global end_date
                end_date="2020-03-31"#Set End_date(yy/mon/day)

                
                region=kiserian
     
                image = geemap.dynamic_world_s2(region, start_date, end_date)
                vis_params3 = {'bands': ['B4', 'B3', 'B2'], 'min': 0, 'max': 3000}
                global landcover
                # Create Dynamic World land cover composite
                global landcover
                landcover = geemap.dynamic_world(region, start_date, end_date, return_type='hillshade')

                # Add legend to the map
                legend_dict = {
    'Water & River ':'2669d6',
    'Vegetation': '5ed68b',
    'GrassLand':'acd698',
    'Crops':'eaff08',
    'Shrubs & Scrub':'fdffc3',
    'Built-up area':'ff0707',
    'BareGround':'14fffa'
                }
                Map.add_legend(legend_dict=legend_dict,position='topleft')
                Map.addLayer(landcover.clip(region),{},'LULCC') 
                
#Final Output   
                global flood_palette
                flood_palette = ['0000FF']
                global flood_class1
                flood_class1 = before_filter.gt(-42).And(after_filter.lt(-26))
                global flood_mask_class1
                flood_mask_class1 = flood_class1.updateMask(flood_class1.eq(1))
                global flood_class2
                flood_class2 = before_filter.gt(-42).And(after_filter.lt(-25))
                global flood_mask_class2
                flood_mask_class2 = flood_class2.updateMask(flood_class2.eq(1))
                
                global flood_class3
                flood_class3 = before_filter.gt(-42).And(after_filter.lt(-24))
                global flood_mask_class3
                flood_mask_class3 = flood_class3.updateMask(flood_class3.eq(1))

                global flood_class4
                flood_class4 = before_filter.gt(-42).And(after_filter.lt(-23))
                global flood_mask_class4
                flood_mask_class4 = flood_class4.updateMask(flood_class4.eq(1))
                
                global flood_class5
                flood_class5 = before_filter.gt(-42).And(after_filter.lt(-22))
                global flood_mask_class5
                flood_mask_class5 = flood_class5.updateMask(flood_class5.eq(1))
                
                global flood_class6
                flood_class6 = before_filter.gt(-42).And(after_filter.lt(-21))
                global flood_mask_class6
                flood_mask_class6 = flood_class6.updateMask(flood_class6.eq(1))
                
                global flood_class7
                flood_class7 = before_filter.gt(-42).And(after_filter.lt(-20))
                global flood_mask_class7
                flood_mask_class7 = flood_class7.updateMask(flood_class7.eq(1))

                global flood_class8
                flood_class8 = before_filter.gt(-42).And(after_filter.lt(-19))
                global flood_mask_class8
                flood_mask_class8 = flood_class8.updateMask(flood_class8.eq(1))
                global flood_class9
                flood_class9 = before_filter.gt(-42).And(after_filter.lt(-18))
                global flood_mask_class9
                flood_mask_class9 = flood_class9.updateMask(flood_class9.eq(1))
                global flood_class10
                flood_class10 = before_filter.gt(-42).And(after_filter.lt(-17))
                global flood_mask_class10
                flood_mask_class10 = flood_class10.updateMask(flood_class10.eq(1))
                
                global flood_class11
                flood_class11 = before_filter.gt(-42).And(after_filter.lt(-16))
                global flood_mask_class11
                flood_mask_class11 = flood_class11.updateMask(flood_class11.eq(1))
                
                global flood_class12
                flood_class12 = before_filter.gt(-42).And(after_filter.lt(-15))
                global flood_mask_class12
                flood_mask_class12 = flood_class12.updateMask(flood_class12.eq(1))
                
                global flood_class13
                flood_class13 = before_filter.gt(-42).And(after_filter.lt(-14))
                global flood_mask_class13
                flood_mask_class13 = flood_class13.updateMask(flood_class13.eq(1))
                
                global flood_class14
                flood_class14 = before_filter.gt(-42).And(after_filter.lt(-13))
                global flood_mask_class14
                flood_mask_class14 = flood_class14.updateMask(flood_class14.eq(1))
                global flood_class15
                flood_class15 = before_filter.gt(-42).And(after_filter.lt(-12))
                global flood_mask_class15
                flood_mask_class15 = flood_class15.updateMask(flood_class13.eq(1))
                
                global flood_class16
                flood_class16= before_filter.gt(-42).And(after_filter.lt(-11))
                global flood_mask_class16
                flood_mask_class16 = flood_class16.updateMask(flood_class16.eq(1))
#Conditional classes
#Breaking of reclassified imaged into more than one class.
# Rainfall_Amount2=predicted_water_level
                User_Rainfall_Amount=(np.array(Rainfall_Amount1).reshape(1,-1))
                predicted_riverlevel=rain_level_regressor.predict(User_Rainfall_Amount)
                print("Expected water rise will be",predicted_riverlevel)
                
                if predicted_riverlevel>=0 and predicted_riverlevel<=2:
                        Map.addLayer(flood_mask_class1,{'palette':flood_palette},"Flood Affected Region (I)")
                       
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="green", icon="info-sign"),
                        ).add_to(Map)
                        global flood_mask_class_area
                        flood_mask_class_area=9.547
                        global unflooded_1
                        unflooded_1=56.890-flood_mask_class_area
                        print("The expected water rise will be approximately 2meters")
                elif predicted_riverlevel>=0 and predicted_riverlevel<=4:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="green", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class2,{'palette':flood_palette},"Flood Affected Region (II)")
                        print("The expected water rise will be approximately 4 meters")
                        flood_mask_class_area=10.020
                        unflooded_1=56.890-flood_mask_class_area
                elif predicted_riverlevel>=0 and predicted_riverlevel<=5:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="blue", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class3,{'palette':flood_palette},"Flood Affected Region (III)")
                        print("The expected water rise will be approximately 5 meters")
                        flood_mask_class_area=10
                        unflooded_1=56.890-flood_mask_class_area
                elif predicted_riverlevel>=0 and predicted_riverlevel<=7:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="blue", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class4,{'palette':flood_palette},"Flood Affected Region (IV)")
                        print("The expected water rise will be approximately 7 meters")
                        flood_mask_class_area=10.880
                        unflooded_1=56.890-flood_mask_class_area
                        
                elif predicted_riverlevel>=0 and predicted_riverlevel<=9:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class5,{'palette':flood_palette},"Flood Affected Region (V)")
                        print("The expected water rise will be approximately 9 meters")
                        flood_mask_class_area=11.399
                        unflooded_1=56.890-flood_mask_class_area
                elif predicted_riverlevel>=0 and predicted_riverlevel<=12:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class6,{'palette':flood_palette},"Flood Affected Region  (VI)'")
                        print("The expected water rise will be approximately 12 meters")
                        flood_mask_class_area=12.112
                        unflooded_1=56.890-flood_mask_class_area
                elif predicted_riverlevel>=0 and predicted_riverlevel<=14:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        slope_palette1 = ['0000FF']
                        Map.addLayer(flood_mask_class7,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 14 meters")
                        flood_mask_class_area=13.259
                        unflooded_1=56.890-flood_mask_class_area
                        
                elif predicted_riverlevel>=0 and predicted_riverlevel<=17:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class8,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 17 meters")
                        flood_mask_class_area=15.158
                        unflooded_1=56.890-flood_mask_class_area
                elif predicted_riverlevel>=0 and predicted_riverlevel<=19:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class9,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 19 meters")
                        flood_mask_class_area=18.441
                        unflooded_1=56.890-flood_mask_class_area
                elif predicted_riverlevel>=0 and predicted_riverlevel<=21:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
    
                        Map.addLayer(flood_mask_class10,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 21 meters")
                        flood_mask_class_area=23.538000
                        unflooded_1=56.890-flood_mask_class_area
                elif predicted_riverlevel>=0 and predicted_riverlevel<=27:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        slope_palette1 = ['0000FF']
    
                        Map.addLayer(flood_mask_class11,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 27 meters")
                        flood_mask_class_area=31.114
                        unflooded_1=56.890-flood_mask_class_area

                elif predicted_riverlevel>=0 and predicted_riverlevel<=28:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
    
                        Map.addLayer(flood_mask_class12,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 28 meters")
                        flood_mask_class_area=39.358
                        unflooded_1=56.890-flood_mask_class_area
                elif predicted_riverlevel>=0 and predicted_riverlevel<=31:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class13,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        # global flood_mask_class_area
                        flood_mask_class_area=39.358
                        # global unflooded_1 
                        unflooded_1=56.890-flood_mask_class_area
                        print("The expected water rise will be approximately 31 meters")
                        flood_mask_class_area=46.027
                        unflooded_1=56.890-flood_mask_class_area
                elif predicted_riverlevel>=0 and predicted_riverlevel<=35:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class14,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 35 meters")
                        flood_mask_class_area=50.439
                        unflooded_1=56.890-flood_mask_class_area
                elif predicted_riverlevel>=0 and predicted_riverlevel<=37:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class15,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 37 meters")
                        flood_mask_class_area=51.234
                        unflooded_1=56.890-flood_mask_class_area

                elif predicted_riverlevel>=0 and predicted_riverlevel<=400:
                        for i in range(0,len(gdf1)):
                            html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://weather.co.ke/kenya/">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class16,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 40 meters")
                        flood_mask_class_area=52.166
                        unflooded_1=56.890-flood_mask_class_area

#End of Conditional classes
#Areas Estimaion in km
                imp_finalFloodedArea = flood_mask_class2
                floodedArea = imp_finalFloodedArea.multiply(ee.Image.pixelArea())

                floodedAreaSize = floodedArea.reduceRegion( **{
      'reducer': ee.Reducer.sum(),
      'geometry': kiserian.geometry(),
      'scale': 30, 
      'maxPixels': 1e13})

# Convert the floodedAreaSize to hectares (area calculations are originally given in meters)
# divide by 10,000 to convert to hectare
# floodedAreaSize = floodedAreaSize.getNumber('water') \
#                         .divide(10000) \
#                         .round()
# print(floodedAreaSize,"testarea")
                        # floodedAreaSize.getInfo()
                        
                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"flood_flow": figure}




#Integration with Refined lee method 
# class flood_flow(TemplateView):
#         template_name = "flood_flow.html"
#         def get_context_data(request):
#                 figure = folium.Figure()
#                 Map = geemap.Map(
#                 location=[0.5327408978908402, 36.12095065065061],
#                 zoom_start=13,
#                 plugin_Draw = True
#         )
#                 Map.add_to(figure)
#                 keserian = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
#                 Map.addLayer(keserian,{},"Keserian")
                
#                 srtm=ee.Image("USGS/SRTMGL1_003")
#                 elev = srtm.select('elevation');
# # Get slope
#                 slope = ee.Terrain.slope(elev);
# # Map.addLayer(slope,{},"slope")

# # Clip Srtm DEM by geometry
#                 keserian_slope= slope.clip(keserian);
#                 slope_palette1 = ['0C7600','4CE500','B2FF18','FFFF00','FFAE00','ff6d66','FF0000']
#                 Map.addLayer(keserian_slope,{'palette':slope_palette1},"keserian_slope")
#                 global slope_palette
#                 slope_palette = ['ff0000','0000FF']
# ###Quarying and Reclassification.
# #SAMPLE EXAMPLE OF RECLASSIFICATION BASED ON RANGE:
#                 first_class=ee.Image(1) \
#         .where(keserian_slope.lte(0), 1)
#                 second=ee.Image(1)\
#         .where(keserian_slope.lte(3), 2)
#                 global thrid_class
#                 thrid_class=ee.Image(1) \
#         .where(keserian_slope.lte(6), 3)
#                 four_class=ee.Image(1) \
#         .where(keserian_slope.lte(15), 4)
#                 fifth_class=ee.Image(1) \
#         .where(keserian_slope.lte(21), 5)
#                 sixth_class=ee.Image(1) \
#         .where(keserian_slope.lte(41), 6)
#                 final_class=ee.Image(1) \
#         .where(keserian_slope.gt(41), 7)
#                 # Map.remove_colorbars()
#                 vis_params = {          
#                             'min': 0,
#                             'max': 41,
#                             'palette':['0C7600','4CE500','B2FF18','FFFF00','FFAE00','ff6d66','FF0000'],
#                     }
#                 colors = vis_params['palette']
#                 vmin = vis_params['min']
#                 vmax = vis_params['max']
#                 Map.add_colorbar(vis_params,label='Keserian Slope(M)')
# #Adding colorbar for flood flow colorbar             
#                 vis_params = {          
#                             'min': 0,
#                             'max': 41,
#                             'palette':['blue','red'
#                                        ],
#                     }
#                 colors = vis_params['palette']
#                 vmin = vis_params['min']
#                 vmax = vis_params['max']
#                 Map.add_colorbar(vis_params,label='Water Flow')
                
                

#                 predicted_riverlevel=predicted_water_level_value
#                 print("Expected water rise will be",predicted_riverlevel)
#                 if predicted_riverlevel>=-100 and predicted_riverlevel<=1:
#                         Map.addLayer(first_class.clip(keserian), {'palette':slope_palette}, 'Flood Affected Region 1');
#                         global plot
#                         plot=gdf1.drop(columns=["state","geom","gid"])
#                         Map.add_points_from_xy(plot,x="longitude", y="latitude")
#                         print("It save zero chance of flood occurance!!")
#                 elif predicted_riverlevel>=2 and predicted_riverlevel<=3:
#                         plot=gdf1.drop(columns=["state","geom","gid"])
#                         Map.add_points_from_xy(plot,x="longitude", y="latitude")
#                         Map.addLayer(second.clip(keserian), {'palette':slope_palette}, 'Flood Affected Region 2');
#                         print("The water level will rise be on the look out!!")
#                 elif predicted_riverlevel>=4 and predicted_riverlevel<=10:
#                         plot=gdf1.drop(columns=["state","geom","gid"])
#                         Map.add_points_from_xy(plot,x="longitude", y="latitude")
#                         Map.addLayer(thrid_class.clip(keserian), {'palette':slope_palette}, 'Flood Affected Region 3');
#                         print("This area will be flooded!!")
#                 elif predicted_riverlevel>=11 and predicted_riverlevel<=20:
#                         plot=gdf1.drop(columns=["state","geom","gid"])
#                         Map.add_points_from_xy(plot,x="longitude", y="latitude")
#                         Map.addLayer(four_class.clip(keserian), {'palette':slope_palette}, 'Flood Affected Region 4');
#                         print("please vacate")
#                 elif predicted_riverlevel>=21 and predicted_riverlevel<=29:
#                         plot=gdf1.drop(columns=["state","geom","gid"])
#                         Map.add_points_from_xy(plot,x="longitude", y="latitude") 
#                         Map.addLayer(fifth_class.clip(keserian), {'palette':slope_palette}, 'Flood Affected Region 5');
#                         print("If you not vacate....please vacate!!!!")
#                 elif predicted_riverlevel>=30 and predicted_riverlevel<=41:
#                         plot=gdf1.drop(columns=["state","geom","gid"])
#                         Map.add_points_from_xy(plot, x="longitude", y="latitude")
#                         Map.addLayer(sixth_class.clip(keserian), {'palette':slope_palette}, 'Flood Affected Region  6');
#                         print("Heavy flood approcing")
#                 elif predicted_riverlevel>45:
#                         plot=gdf1.drop(columns=["state","geom","gid"])
#                         Map.add_points_from_xy(plot, x="longitude", y="latitude")
#                         slope_palette1 = ['0000FF']
#                         Map.addLayer(final_class.clip(keserian), {'palette':slope_palette1}, 'Flood Affected Region  7');
#                         print("The whole region has been submerged!!!!")


#                 Map.add_child(folium.LayerControl())
#                 figure.render()
#                 return{"flood_flow": figure}



            
                
# def home(request):
#         return render(request,"home.html")
################
###Select Data##
################
class home(TemplateView):
        template_name = "Homepage.html"
        def get_context_data(request):
                global connection
                connection=ps.connect(dbname="KSA",#Database_name.
                 user="postgres",#Database_user.
                 password="Mosong6783",#Database_passcode.
                 host="localhost",#Db Host
                 port="5432"#Db operational port
                )
                global sql

                
                return{"home":figure}
        
#####################################
########Image preprocessing begins###
###################################
#Image preprocessing:2017
class sentinel_data(TemplateView):
        template_name = 'sentinelData.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[0.5327408978908402, 36.12095065065061],
            zoom_start=13,
            plugin_Draw = True, 
        #     Draw_export = True
        )
                Map.add_to(figure)
        
                style = {'color': '131313', 'fillColor':' FD0505'}
                
                global muringato
                muringato = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
        
                Map.center_object(muringato,13);
                start_date="2020-01-01"#Set start_date(yy/mon/day)
                end_date="2020-03-31"#Set End_date(yy/mon/day)
                season = ee.Filter.date(start_date,end_date);#Filter image based on the time frame(start_date and end_date
                
                global sentinel_image
                sentinel_1= ee.ImageCollection('COPERNICUS/S1_GRD');
                sCollection=sentinel_1\
                    .filterBounds(muringato) \
                    .filter(season) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV')) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH')) \
                    .filter(ee.Filter.eq('instrumentMode', 'IW'))
              
                desc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
                asc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));

                global composite
                composite = ee.Image.cat([
                asc.select('VH').mean(),
                asc.select('VV').mean(),
                desc.select('VH').mean()
                ]).focal_median();
   
 #-------------SENTINEL_2A DATA----------------------#  
                global sentinel_2A
                sentinel_2A = ee.ImageCollection('COPERNICUS/S2')\
               .filterBounds(muringato)\
               .filterDate("2020-01-01","2020-03-31")\
               .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",10))\
               .median()\
               .select('B1','B2', 'B3', 'B4', 'B5', 'B6', 'B7','B8', 'B10', 'B11')\
               .clip(muringato)
                
                sentinel_2Avispar={"min":0, "max":2500,"bands": ['B4','B3','B2']}#Visualization parameters used.

                Map.addLayer(sentinel_2A,sentinel_2Avispar,"sentinel 2A")
                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"sentinel_data": figure}
        

###############################
#Image preprocessing:2021.
class sentinel_data_2021(TemplateView):
        template_name = 'sentinelData.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[0.5327408978908402, 36.12095065065061],
            zoom_start=13,
            plugin_Draw = True, 
        #     Draw_export = True
        )
                Map.add_to(figure)
        
                style = {'color': '131313', 'fillColor':' FD0505'}
                
                global muringato
                muringato = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
        
                Map.center_object(muringato,13);
                start_date="2021-01-01"#Set start_date(yy/mon/day)
                end_date="2021-03-31"#Set End_date(yy/mon/day)
                season = ee.Filter.date(start_date,end_date);#Filter image based on the time frame(start_date and end_date
                
                global sentinel_image
                sentinel_1= ee.ImageCollection('COPERNICUS/S1_GRD');
                sCollection=sentinel_1\
                    .filterBounds(muringato) \
                    .filter(season) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV')) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH')) \
                    .filter(ee.Filter.eq('instrumentMode', 'IW'))
              
                desc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
                asc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));

                global composite
                composite = ee.Image.cat([
                asc.select('VH').mean(),
                asc.select('VV').mean(),
                desc.select('VH').mean()
                ]).focal_median();
   
 #-------------SENTINEL_2A DATA----------------------#  
                global sentinel_2A
                sentinel_2A = ee.ImageCollection('COPERNICUS/S2')\
               .filterBounds(muringato)\
               .filterDate("2021-01-01","2021-03-31")\
               .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",10))\
               .median()\
               .select('B1','B2', 'B3', 'B4', 'B5', 'B6', 'B7','B8', 'B10', 'B11')\
               .clip(muringato)
                
                sentinel_2Avispar={"min":0, "max":2500,"bands": ['B4','B3','B2']}#Visualization parameters used.

                Map.addLayer(sentinel_2A,sentinel_2Avispar,"sentinel 2A")
                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                return{"sentinel_data_2021": figure}



###############################
#Image preprocessing:2018.
class sentinel_data1(TemplateView):
        template_name = 'sentinelData.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
                        location=[0.5327408978908402, 36.12095065065061],
                        zoom_start=13,
                        plugin_Draw = True
                        )
                Map.add_to(figure)
                style = {'color': '131313', 'fillColor':' FD0505'}
                
                global muringato
                muringato = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
        
                Map.center_object(muringato,13);
              
   
 #-------------SENTINEL_2A DATA----------------------#  
                global sentinel_2A
                sentinel_2A = ee.ImageCollection('COPERNICUS/S2')\
               .filterBounds(muringato)\
               .filterDate("2020-01-01","2020-03-31")\
               .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",10))\
               .median()\
               .select('B1','B2', 'B3', 'B4', 'B5', 'B6', 'B7','B8', 'B10', 'B11')\
               .clip(muringato)
                
                sentinel_2Avispar={"min":0, "max":2500,"bands": ['B4','B3','B2']}#Visualization parameters used.

                Map.addLayer(sentinel_2A,sentinel_2Avispar,"sentinel 2A")
                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"sentinel_data1": figure}


############################+###
#Image preprocessing:2019.
class sentinel_data(TemplateView):
        template_name = 'sentinelData.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[0.5327408978908402, 36.12095065065061],
            zoom_start=13,
            plugin_Draw = True, 
        #     Draw_export = True
        )
                Map.add_to(figure)
        
                style = {'color': '131313', 'fillColor':' FD0505'}
                
                global muringato
                muringato = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
        
                Map.center_object(muringato,13);
                start_date="2020-01-01"#Set start_date(yy/mon/day)
                end_date="2020-03-31"#Set End_date(yy/mon/day)
                season = ee.Filter.date(start_date,end_date);#Filter image based on the time frame(start_date and end_date
                
                global sentinel_image
                sentinel_1= ee.ImageCollection('COPERNICUS/S1_GRD');
                sCollection=sentinel_1\
                    .filterBounds(muringato) \
                    .filter(season) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV')) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH')) \
                    .filter(ee.Filter.eq('instrumentMode', 'IW'))
              
                desc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
                asc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));

                global composite
                composite = ee.Image.cat([
                asc.select('VH').mean(),
                asc.select('VV').mean(),
                desc.select('VH').mean()
                ]).focal_median();
   
 #-------------SENTINEL_2A DATA----------------------#  
                global sentinel_2A
                sentinel_2A = ee.ImageCollection('COPERNICUS/S2')\
               .filterBounds(muringato)\
               .filterDate("2020-01-01","2020-03-31")\
               .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",10))\
               .median()\
               .select('B1','B2', 'B3', 'B4', 'B5', 'B6', 'B7','B8', 'B10', 'B11')\
               .clip(muringato)
                
                sentinel_2Avispar={"min":0, "max":2500,"bands": ['B4','B3','B2']}#Visualization parameters used.

                Map.addLayer(sentinel_2A,sentinel_2Avispar,"sentinel 2A")
                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"sentinel_data": figure}


###############################
#Image preprocessing:2020.
class sentinel_data(TemplateView):
        template_name = 'sentinelData.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[0.5327408978908402, 36.12095065065061],
            zoom_start=13,
            plugin_Draw = True, 
        #     Draw_export = True
        )
                Map.add_to(figure)
        
                style = {'color': '131313', 'fillColor':' FD0505'}
                
                global muringato
                muringato = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
        
                Map.center_object(muringato,13);
                start_date="2020-01-01"#Set start_date(yy/mon/day)
                end_date="2020-03-31"#Set End_date(yy/mon/day)
                season = ee.Filter.date(start_date,end_date);#Filter image based on the time frame(start_date and end_date
                
                global sentinel_image
                sentinel_1= ee.ImageCollection('COPERNICUS/S1_GRD');
                sCollection=sentinel_1\
                    .filterBounds(muringato) \
                    .filter(season) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV')) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH')) \
                    .filter(ee.Filter.eq('instrumentMode', 'IW'))
              
                desc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
                asc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));

                global composite
                composite = ee.Image.cat([
                asc.select('VH').mean(),
                asc.select('VV').mean(),
                desc.select('VH').mean()
                ]).focal_median();
   
 #-------------SENTINEL_2A DATA----------------------#  
                global sentinel_2A
                sentinel_2A = ee.ImageCollection('COPERNICUS/S2')\
               .filterBounds(muringato)\
               .filterDate("2020-01-01","2020-03-31")\
               .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",10))\
               .median()\
               .select('B1','B2', 'B3', 'B4', 'B5', 'B6', 'B7','B8', 'B10', 'B11')\
               .clip(muringato)
                
                sentinel_2Avispar={"min":0, "max":2500,"bands": ['B4','B3','B2']}#Visualization parameters used.

                Map.addLayer(sentinel_2A,sentinel_2Avispar,"sentinel 2A")
                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"sentinel_data": figure}


###############################
#Image preprocessing:2022.
class sentinel_data_2022(TemplateView):
        template_name = 'sentinelData1.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[0.5327408978908402, 36.12095065065061],
            zoom_start=13,
            plugin_Draw = True, 
        #     Draw_export = True
        )
                Map.add_to(figure)
        
                style = {'color': '131313', 'fillColor':' FD0505'}
                
                global muringato
                muringato = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
        
                Map.center_object(muringato,13);
                start_date="2020-01-01"#Set start_date(yy/mon/day)
                end_date="2020-03-31"#Set End_date(yy/mon/day)
                season = ee.Filter.date(start_date,end_date);#Filter image based on the time frame(start_date and end_date
                
                global sentinel_image
                sentinel_1= ee.ImageCollection('COPERNICUS/S1_GRD');
                sCollection=sentinel_1\
                    .filterBounds(muringato) \
                    .filter(season) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV')) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH')) \
                    .filter(ee.Filter.eq('instrumentMode', 'IW'))
              
                desc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
                asc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));

                global composite
                composite = ee.Image.cat([
                asc.select('VH').mean(),
                asc.select('VV').mean(),
                desc.select('VH').mean()
                ]).focal_median();
   
 #-------------SENTINEL_2A DATA----------------------#  
                global sentinel_2A
                sentinel_2A = ee.ImageCollection('COPERNICUS/S2')\
               .filterBounds(muringato)\
               .filterDate("2020-01-01","2020-03-31")\
               .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",10))\
               .median()\
               .select('B1','B2', 'B3', 'B4', 'B5', 'B6', 'B7','B8', 'B10', 'B11')\
               .clip(muringato)
                
                sentinel_2Avispar={"min":0, "max":2500,"bands": ['B4','B3','B2']}#Visualization parameters used.

                Map.addLayer(sentinel_2A,sentinel_2Avispar,"sentinel 2A")
                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"sentinel_data": figure}

########Draw_AOI
class Draw_AOI(TemplateView):
        template_name = 'ROI.html'
        def get_context_data(request):
                global figure
                figure = folium.Figure()
                
                global Map
                Map = geemap.Map()
                Map.add_to(figure)
                # geometry = ee.Geometry.Rectangle([80.058, 26.347, 82.201, 28.447]) 
                # Map.addLayer(geometry,{},"Boundaries")
                
                # feature = Map.draw_last_feature
                # ROI = feature.geometry()
                global boundaries
                boundaries=Map.user_rois
                
                # geometry = ee.FeatureCollection(layers_as_features)
                Map.addLayer(ee.Feature(boundaries), {}, "boundaries");
                # Map.addLayer(boundaries,{},"Region of Intrest")

                # folium.Map.add_ee_layer = Draw_AOI
                features=Draw()
                # plugins.Draw(export=True, filename='data.shp').add_to(Map)  
                
                # ee_object = geemap.shp_to_ee(filename)
                
                
                # ee_object = geemap.shp_to_ee(filename)
                # Map.addLayer(ee_object, {}, 'Layer name')

                # filename.add_to(Map)
                # Map.addLayer(ee_object,{},"Features")
                

                Map.draw_features
                
                roi = ee.FeatureCollection(Map.draw_features)
                
                # selected_states = states.filterBounds(roi)
                Map.addLayer(roi, {}, "Selected states")
                # Map.addLayer(features,{},"Edacs")/
                # Map.draw_last_feature
                sentinel_image = ee.ImageCollection('COPERNICUS/S2').filterDate(
    "2020-07-01","2020-12-31").filterBounds(roi).filter(
    ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",20)).median().clip(roi)
                Map.addLayer(sentinel_image,{},"sentinel")
                
                
                # roi = ee.FeatureCollection(Map.draw_features)
                # selected_states = states.filterBounds(roi)
                # Map.addLayer(roi, {}, "Selected states")
                
                # global muringato
                muringato= ee.FeatureCollection("users/MosongJrn/KSA_Study_Area_Projected0")
                Map.addLayer(muringato,{},"muringato")
#                 sentinel_image = ee.ImageCollection('COPERNICUS/S2').filterDate(
#     "2020-07-01","2020-12-31").filterBounds(muringato).filter(
#     ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",20)).median().select("B4","B3","B2").clip(muringato)
#                 sentinel_1Avispar={"min":0, "max":2500}#Visualization parameters used.
#                 Map.addLayer(sentinel_image,sentinel_1Avispar,"sentinel_image")
    
                
                 
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"Draw_AOI": figure}



####### Image classification
class classification(TemplateView):
        template_name = 'model.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[0.5327408978908402, 36.12095065065061],
            zoom_start=13,
            plugin_Draw = True
        #     Draw_export = True
        )
                Map.add_to(figure)
                global keserian
                keserian = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
                Map.addLayer(keserian,{},"Keserian")
                training_data=ee.FeatureCollection("projects/ee-mosongjnvscode/assets/kiserian_training_data")
                Map.addLayer(training_data,{},"Kisrian_Training_Data")
                #Create a buffer
                buffered_data = training_data.map(lambda f: f.buffer(5))
                Map.addLayer(buffered_data,{},"Buffered data")
                
                sentinel_image = ee.ImageCollection('COPERNICUS/S2').filterDate(
    "2020-07-01","2020-12-31").filterBounds(keserian).filter(
    ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",20)).median().select("B4","B3","B2").clip(keserian)
              
                
####Training the model.####
                Band_selection=["B4","B3","B2"]
                training = sentinel_image.sampleRegions(**{
  'collection': training_data,#samples.
  'properties': ['landcover'],
  'scale': 30
})
                #/SPLITS:Training(75%) & Testing samples(25%).
        
                Total_samples=training.randomColumn('random')
                training_samples=Total_samples.filter(ee.Filter.lessThan('random',0.75))
                validation_samples=Total_samples.filter(ee.Filter.greaterThanOrEquals('random',0.75))
                label = 'landcover'
                
                # Train the classifier.
# trained = classifier.train(training, 'class', bands)
                init_params = {"numberOfTrees":10, # the number of individual decision tree models
              "variablesPerSplit":None,  # the number of features to use per split
              "minLeafPopulation":1, # smallest sample size possible per leaf
              "bagFraction":0.5, # fraction of data to include for each individual tree model
              "maxNodes":None, # max number of leafs/nodes per tree
               "seed":0}  # random seed for "random" choices like sampling. Setting this allows others to reproduce your exact results even with stocastic parameters

                clf = ee.Classifier.smileRandomForest(**init_params).train(training, label, Band_selection)
# Classify the image.
                global classified
                classified = sentinel_image.classify(clf)
                
                # Map.addLayer(polygons, {}, 'training polygons')#Adding polygons to layers
                global classification_palette
                classification_palette=[
  '#14fffa',#BareLand :0  
  '#ff0707',#Buildings:1
  '#5ed68b',#Vegetation:2
  '#eaff08',#Agricultral:3#
  '#2669d6', #Water Bodies4#
]
                Map.addLayer(classified,
            {'min': 0, 'max': 4, 'palette': classification_palette},
             'classification')
                
#Area estimation;  
                Total_studyArea= classified.geometry().area()
                
                Total_AreaSqKm = ee.Number(Total_studyArea).divide(4046.86).round()
                
                names = [ 'BareLand','Buildings','Vegetation','Agricultral','Water Bodies']
                count = classified.eq([0,1,2,3,4])
                Estimated_area = count.multiply(ee.Image.pixelArea()).divide(4046.86).rename(names)#mutiply and divide the area with 1e6 to conv into km

                classification_areas = Estimated_area.reduceRegion(**{
                        'reducer': ee.Reducer.sum(),
                        'geometry': keserian,
                        'scale': 30,
                        'maxPixels': 1e9})
                def trancuate(key, value):
                        return ee.Number(value).format('%.3f')
                global areatran
                areatran = classification_areas.map(trancuate)
                # areatran.getInfo()
                # print(areatran,"areatran")
# print(areatran,"areatran")
                
#Dyanmic world Image Classifcation:
                global start_date
                start_date="2020-01-01"#Set start_date(yy/mon/day)
                global end_date
                end_date="2020-03-31"#Set End_date(yy/mon/day)

                # import geopandas as gdp
                # test_data=gdp.read_file(r"C:\Users\user\Downloads\Area_of_Intrest.geojson")
#                 feature_collection = geemap.gdf_to_ee(test_data)#FROM GDF TO ee feature collection
#                 style = {'color': '131313', 'fillColor':' FD0505'}
                
#                 Map.addLayer(feature_collection.style(**style),{}, "Drawn ROI",False)#Ad

     
#                 image = geemap.dynamic_world_s2(region, start_date, end_date)
#                 vis_params3 = {'bands': ['B4', 'B3', 'B2'], 'min': 0, 'max': 3000}
#                 global landcover
#                 # Create Dynamic World land cover composite
#                 global landcover
#                 landcover = geemap.dynamic_world(region, start_date, end_date, return_type='hillshade')

#                 # Add legend to the map
#                 legend_dict = {
#     'Water & River ':'2669d6',
#     'Vegetation': '5ed68b',
#     'GrassLand':'acd698',
#     'Crops':'eaff08',
#     'Shrubs & Scrub':'fdffc3',
#     'Built-up area':'ff0707',
#     'BareGround':'14fffa'
#                 } 
#                 Map.add_legend(legend_title="Classification", legend_dict=legend_dict)

#                 Map.addLayer(landcover.clip(region),{},'LULCC',False)
                # Map.add_legend(title="Land Cover", builtin_legend='Dynamic_World')
                
                    
                legend_dict = {
    'BareLand': 'd6ba61',#1
    'Buildings': '09080c',#
    'Vegetation': '33698b',#
    'Agricultral': 'ff2407',
    'Water Bodies': '00ffff',#
            }
                Map.add_legend(legend_dict=legend_dict,position='topleft')

                


                
                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"classification": figure}

from django.shortcuts import render
from .models import Post


def createpost(request):
        if request.method == 'POST':
                title= request.POST['title']  
                content= request.POST['content']
                new_book=Post(title=title,content=content)
                new_book.save()
        return render(request, 'index.html',{})   

        





# def createpost(request):
#         template_name = 'createpost.html'
#         if request.method == 'POST':
#             if request.POST.get('title') and request.POST.get('content'):
#                 post=Post()
#                 post.title= request.POST.get('title')
#                 post.content= request.POST.get('content')
#                 post.save()
                
#                 return render(request, 'posts/create.html')  

#         else:
#                 return render(request,'posts/create.html')


################
####################################
###########  Text AREA  ###########
####################################
# class editForm(forms.Form):
#         title=forms.CharField(widget=forms.TextInput(attrs={'name':'title'}))
#         body =forms.CharField(widget=forms.TextInput(attrs={'name':'body','rows':3,'cols':5}))
# def new(request):
#         return render(request)
# Render user inputs
from django.shortcuts import render
from .models import MyModel,floodreader1
from .forms import MyForm,MyForm1
class input(TemplateView): 
    template_name = 'index.html'
def my_form(request):
  if request.method == "POST":
    form = MyForm1(request.POST)
    if form.is_valid():
      form.save()
  else:
      form = MyForm1()
  return render(request, 'inputs.html', {'form': form})

        

############################################
######sentinel data
##############################
class sentinel_data11(TemplateView):
        template_name = 'hyper/index78.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[0.5327408978908402, 36.12095065065061],
            zoom_start=13,
            plugin_Draw = True, 
        #     Draw_export = True
        )
                Map.add_to(figure)
                
                global muringato
                muringato = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
        
                Map.center_object(muringato,13);
                start_date="2020-01-01"#Set start_date(yy/mon/day)
                end_date="2020-03-31"#Set End_date(yy/mon/day)
                season = ee.Filter.date(start_date,end_date);#Filter image based on the time frame(start_date and end_date
                
                global sentinel_image
                sentinel_1= ee.ImageCollection('COPERNICUS/S1_GRD');
                sCollection=sentinel_1\
                    .filterBounds(muringato) \
                    .filter(season) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV')) \
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH')) \
                    .filter(ee.Filter.eq('instrumentMode', 'IW'))
              
                desc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
                asc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));

                global composite
                composite = ee.Image.cat([
                asc.select('VH').mean(),
                asc.select('VV').mean(),
                desc.select('VH').mean()
                ]).focal_median();
   
 #-------------SENTINEL_2A DATA----------------------#  
                global sentinel_2A
                sentinel_2A = ee.ImageCollection('COPERNICUS/S2')\
               .filterBounds(muringato)\
               .filterDate("2020-01-01","2020-03-31")\
               .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",10))\
               .median()\
               .select('B1','B2', 'B3', 'B4', 'B5', 'B6', 'B7','B8', 'B10', 'B11')\
               .clip(muringato)
                
                sentinel_2Avispar={"min":0, "max":2500,"bands": ['B4','B3','B2']}#Visualization parameters used.

                Map.addLayer(sentinel_2A,sentinel_2Avispar,"sentinel 2A")
                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"sentinel_data11": figure}

 
class population_affected(TemplateView): 
    template_name = 'population.html'

    def get_context_data(request):
        global figure
        figure = folium.Figure()
        global Map
        Map = geemap.Map()
        
        plugins.LocateControl().add_to(Map)
# #Add measure tool 
        plugins.MeasureControl(position='bottomleft', primary_length_unit='meters', secondary_length_unit='miles', primary_area_unit='sqmeters', secondary_area_unit='acres').add_to(Map)
        keserian = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
        Map.addLayer(keserian,{},"kISERIAN SHAPEFILE")
        Map.center_object(keserian,13)
        buildings = ee.FeatureCollection('GOOGLE/Research/open-buildings/v1/polygons');
        global keserian_buildings
        keserian_buildings=buildings\
        .filter('confidence >= 0.70')\
        .filterBounds(keserian)\
        
        Map.addLayer(keserian_buildings,{'color': 'ff0000'},"ROI Population")
        
        #Creation of heat map

        def func_tbb(buildinds_feature_collection):
            return buildinds_feature_collection.set('google_buildinds',1)

        google_buildings = keserian_buildings.map(func_tbb)

        def heatmap(google_buildings,radius):
            ptImg = google_buildings.reduceToImage(['google_buildinds'],ee.Reducer.first()).unmask(0)
            kernel = ee.Kernel.circle(radius)
            result = ptImg.convolve(kernel)
            return result.updateMask(result.neq(0))

# Adjust the buffering radius
        Buildings_heatmap = heatmap(google_buildings,8)
#Colour Gradient
        gradient = ['green','yellow','red']
        
        
        
        
        
#Conditional classes for popuplation

#Breaking of reclassified imaged into more than one class.
# Rainfall_Amount2=predicted_water_level

        User_Rainfall_Amount=(np.array(Rainfall_Amount1).reshape(1,-1))
        predicted_riverlevel=rain_level_regressor.predict(User_Rainfall_Amount)
        print("Expected water rise will be",predicted_riverlevel)
        
        if predicted_riverlevel>=0 and predicted_riverlevel<=2:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class1,{'palette':flood_palette},"Flood Affected Region (II)")
                        print("The expected water rise will be approximately 2meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=4:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class2,{'palette':flood_palette},"Flood Affected Region (II)")
                        print("The expected water rise will be approximately 4 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=5:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class3,{'palette':flood_palette},"Flood Affected Region (III)")
                        print("The expected water rise will be approximately 5 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=7:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class4,{'palette':flood_palette},"Flood Affected Region (IV)")
                        print("The expected water rise will be approximately 7 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=9:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class5,{'palette':flood_palette},"Flood Affected Region (V)")
                        print("The expected water rise will be approximately 9 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=12:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        
                        Map.addLayer(flood_mask_class6,{'palette':flood_palette},"Flood Affected Region  (VI)'")
                        print("The expected water rise will be approximately 12 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=14:
                plot=gdf1.drop(columns=["state","geom","gid"])
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class7,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 14 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=17:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        
                        Map.addLayer(flood_mask_class8,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 17 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=19:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class9,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 19 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=21:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class10,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 21 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=27:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class11,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 27 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=28:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        
                        Map.addLayer(flood_mask_class12,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 28 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=31:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class13,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 31 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=35:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class14,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 35 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=37:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class15,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 37 meters")

        elif predicted_riverlevel>=0 and predicted_riverlevel<=40:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        
                        Map.addLayer(flood_mask_class16,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 40 meters")   
       
        #Add layers to be visualized n the map  
        Map.addLayer(Buildings_heatmap,{'palette':gradient, 'min':0, 'max':0.6},'Built-up Regions')
        
        vis_params = {
                    'min': 1,
                    'max': 100,
                    'palette':['green','yellow','red'],
                }
        colors = vis_params['palette']
        vmin = vis_params['min']
        vmax = vis_params['max']
        Map.add_colorbar(vis_params,label='Population(Google Footprint)')
        legend_dict = {
    'BareLand': 'd6ba61',#1
    'Buildings': '09080c',#
    'Vegetation': '33698b',#
    'Agricultral': 'ff2407',
    'Water Bodies': '00ffff',#
                }
        Map.add_legend(legend_dict=legend_dict,position='topleft')
    
        Map.add_to(figure)
  
        Map.add_child(folium.LayerControl())
        
        figure.render()

        return {"population_affected": figure}


# class floodextend(TemplateView):
        
#         template_name='hyper/floodextend.html'
        
class home(TemplateView):
        
         template_name='hyper/home.html'
class studyarea(TemplateView):
        
         template_name='hyper/studyarea.html'
class floodanalysis(TemplateView):
        
         template_name='hyper/floodanalysis.html'
class prediction(TemplateView):
        
         template_name='hyper/prediction.html'
class floodstories(TemplateView):
        
        template_name='hyper/floodstories.html'
class aboutme(TemplateView):
        template_name='hyper/aboutme.html'
class instruction(TemplateView):
        
        template_name='hyper/instruction.html'       
class fetchdb(TemplateView):
        
        
         template_name='hyper/prediction.html'
         
         
class fetchdb(TemplateView): 
    template_name = 'population.html'

    def get_context_data(request):
        global figure
        figure = folium.Figure()
        global Map
        Map = geemap.Map()
        
        plugins.LocateControl().add_to(Map)
# #Add measure tool 
        plugins.MeasureControl(position='bottomleft', primary_length_unit='meters', secondary_length_unit='miles', primary_area_unit='sqmeters', secondary_area_unit='acres').add_to(Map)
       # Connection to KSA(personal_database)
        global connection
        connection=ps.connect(dbname="postgres",#Database_name
                 user="postgres",#Database user name
                 password="Mosong6783",##Database_passcode.
                 host="localhost",#Database host
                 port="5432"##Db operational port
                )
        cursor=connection.cursor()
        sql="""SELECT * FROM "flood_mapper_APP_floodreader1" WHERE Id=(SELECT max(Id) FROM "flood_mapper_APP_floodreader1");"""
        cursor.execute(sql)
        data=cursor.fetchall()

# weather Station from Django user inputs:Row 1
        for Station_row in data:
                ("Rainfall=",Station_row[1])
        inputs_station=Station_row[1]
#Rainfall Readings from Django user inputs:Row 3
        for Rainfall_Amount_row in data:
                ("Rainfall=",Rainfall_Amount_row[3])
        Rainfall_Amount=Rainfall_Amount_row[3]

#Temperature Readings from Django user Inputs:Row 2
        for Temperature_row in data:
                ("Temperature=",Temperature_row[2])
        Temperaturereading=Temperature_row[2]
##Temperature Readings from Django user Inputs:Row 4 
        for time_row in data:
                ("Time=",time_row[4])
        Timeinput=time_row[4]

        print("WeatherStation:",inputs_station)
        print("Temperaturereading:",Temperaturereading)
        print("Rainfall_Amount:",Rainfall_Amount)
        print("Time inputs:",Timeinput)
# data
       
        Map.add_to(figure)
  
        Map.add_child(folium.LayerControl())
        
        figure.render()

        return {"population_affected": figure}

# generationchart for user input data
class generationchart(TemplateView):
        template_name='hyper/chart.html'
        def get_context_data(self, **kwargs):
                context=super().get_context_data(**kwargs)
                context["qs"]=floodreader1.objects.all()
                return context

# generationchart for landuse landcover
class floodextend(TemplateView):
        template_name='hyper/floodextend.html'
        
        # areatran1=temperaturerainfall
        def get_context_data(self, **kwargs):
                context=super().get_context_data(**kwargs)
                context["qs"]=Userinputs_gdf
                return context
        
# Land analysis
class analyzededland(TemplateView): 
    template_name = 'hyper/aboutme.html'

    def get_context_data(request):
        global figure
        figure = folium.Figure()
        global Map
        Map = geemap.Map()
        
        # plugins.Fullscreen().add_to(Map)
        plugins.LocateControl().add_to(Map)
#         #Add the draw 
#         plugins.Draw(export=True, filename='data.shp', position='topleft', draw_options=None, edit_options=None).add_to(Map)  
        
# #Add measure tool 
        plugins.MeasureControl(position='bottomleft', primary_length_unit='meters', secondary_length_unit='miles', primary_area_unit='sqmeters', secondary_area_unit='acres').add_to(Map)
        srtm=ee.Image("USGS/SRTMGL1_003")
        elev = srtm.select('elevation');
        slope = ee.Terrain.slope(elev);
# Map.addLayer(slope,{},"slope")

        # global slope_palette
        slope_palette = ['0000FF']
# Clip Srtm DEM by geometry
        keserian = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
        Map.centerObject(keserian,9)
        ###Record Effects
        keserian_slope= slope.clip(keserian);
        effect1=keserian_slope.lte(0)
        effect_Mask1=effect1.updateMask(effect1)

        effect2=keserian_slope.lte(3)
        effect_Mask2=effect2.updateMask(effect2)

        effect3=keserian_slope.lte(6)
        effect_Mask3=effect3.updateMask(effect3)

        effect4=keserian_slope.lte(15)
        effect_Mask4=effect4.updateMask(effect4)


        effect5=keserian_slope.lte(21)
        effect_Mask5=effect5.updateMask(effect5)


        effect6=keserian_slope.lte(31)
        effect_Mask6=effect6.updateMask(effect6)

        effect7=keserian_slope.lte(41)
        effect_Mask7=effect7.updateMask(effect7)

        slope_palette = ['0000FF']

        
                
#Classification image
        Map.addLayer(classified,
            {'min': 0, 'max': 4, 'palette': classification_palette},
             'classification')
        legend_dict = {
    'BareLand': 'd6ba61',#1
    'Buildings': '09080c',#
    'Vegetation': '33698b',#
    'Agricultral': 'ff2407',
    'Water Bodies': '00ffff',#
                }
        Map.add_legend(legend_dict=legend_dict,position='topleft')
#Breaking of reclassified imaged into more than one class.
        predicted_riverlevel=regressor.predict(predicted_rainfall)
   
        print("Expected water rise will be",predicted_riverlevel)
        if predicted_riverlevel>=0 and predicted_riverlevel<=1:
                Map.addLayer(effect_Mask1, {'min':0, 'max':41, 'palette':slope_palette},"Flood Affected Region 1")
                global plot
                plot=gdf1.drop(columns=["state","geom","gid"])
                Map.add_points_from_xy(plot,x="longitude", y="latitude")
                print("It save zero chance of flood occurance!!(FLOODCOVERAGE)")
        
        elif predicted_riverlevel>=0 and predicted_riverlevel<=3:
                plot=gdf1.drop(columns=["state","geom","gid"])
                Map.add_points_from_xy(plot,x="longitude", y="latitude")
                Map.addLayer(effect_Mask2, {'min':0, 'max':41, 'palette':slope_palette},"Flood Affected Region 2")
                print("The water level will rise be on the look out!!(FLOODCOVERAGE)")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=6:
                plot=gdf1.drop(columns=["state","geom","gid"])
                Map.add_points_from_xy(plot,x="longitude", y="latitude")
                Map.addLayer(effect_Mask3, {'min':0, 'max':41, 'palette':slope_palette},"Flood Affected Region 3")
                print("This area will be flooded!!(FLOODCOVERAGE)")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=15:
                plot=gdf1.drop(columns=["state","geom","gid"])
                Map.add_points_from_xy(plot,x="longitude", y="latitude")
                Map.addLayer(effect_Mask4, {'min':0, 'max':41, 'palette':slope_palette},"Flood Affected Region 4")
                print("please vacate (FLOODCOVERAGE)")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=21:
                plot=gdf1.drop(columns=["state","geom","gid"])
                Map.add_points_from_xy(plot,x="longitude", y="latitude")
                Map.addLayer(effect_Mask5, {'min':0, 'max':41, 'palette':slope_palette},"Flood Affected Region 5")
                print("If you not vacate....please vacate!!!!(FLOODCOVERAGE)")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=41:
                plot=gdf1.drop(columns=["state","geom","gid"])
                Map.add_points_from_xy(plot, x="longitude", y="latitude")
                Map.addLayer(effect_Mask6, {'min':0, 'max':41, 'palette':slope_palette},"Flood Affected Region 6")
                print("Heavy flood approcing(FLOODCOVERAGE)")
        elif predicted_riverlevel>45:
                plot=gdf1.drop(columns=["state","geom","gid"])
                Map.add_points_from_xy(plot, x="longitude", y="latitude")
                slope_palette1 = ['0000FF']
                Map.addLayer(effect_Mask7, {'min':0, 'max':41, 'palette':slope_palette},"Flood Affected Region 7")
        
    
        Map.add_to(figure)
  
        Map.add_child(folium.LayerControl())
        
        figure.render()

        return {"analyzededland": figure}


#sending emails 
from django.core.mail import send_mail
from django.http import HttpResponse

def sendSimpleEmail(request,emailto):
   res = send_mail("hello paul", "comment tu vas?", "paul@polo.com", [emailto])
   return HttpResponse('%s'%res)
import matplotlib.pyplot as plt
import io
import urllib, base64

def prediction (request):
    
    # plt.plot(range(10))
#     flood_mask_class14=34
#     unflooded_1=120
    x = np.array(["Flood Region", "Unflooded Region"])
    y = np.array([flood_mask_class_area, unflooded_1])
    plt.bar(x,y, color=['red', 'green'])
    fig = plt.gcf()
    #convert graph into dtring buffer and then we convert 64 bit code into image
    buf = io.BytesIO()
    fig.savefig(buf,format='png')
    buf.seek(0)
    string = base64.b64encode(buf.read())
    uri =  urllib.parse.quote(string)
    return render(request,'hyper/prediction.html',{'data':uri})



# from django.conf import settings
# from django.core.mail import send_mail

# from django.core.mail import send_mail

# # send_mail(
# #     'Subject here',
# #     'Here is the message.',
# #     'ropluke1@gmail.com',
# #     ['ropluke901@gmail.com'],
# #     fail_silently=False,
# # )


# def contact_us(requset):
#     subject = requset.POST.get('subject', '')
#     message = requset.POST.get('message', '')
#     from_email = requset.POST.get('from_email', '')
#     send_mail(subject, message, from_email, 
#     ['myname@gmail.com'])
#     return render( requset , 'accounts/contact_us.html' )


# #Views for uploading shapefile data 
# import json
# from django.core.serializers import serialize
# from django.views.generic import TemplateView
# from django.http import HttpResponseRedirect, HttpResponse
# from django.urls import reverse_lazy

# from .models import UploadedFile, Shapefile, Geometry

# from .tasks import save_data

# Create your views here.


# class IndexView(TemplateView):
#     template_name = "uploadding.html.html"

#     def get_context_data(self, **kwargs):
#         # Call the base implementation first to get a context
#         context = super().get_context_data(**kwargs)
#         context['geometries'] = Geometry.objects.all().count()
#         context['shapefiles'] = Shapefile.objects.all().count()
#         return context


# def upload_shape(request):
#     files_pk = []
#     UploadedFile.objects.all().delete()
#     if 'shape' in request.FILES:
#         files = request.FILES.getlist('shape')
#         for f in files:
#             uploaded = UploadedFile(document=f)
#             uploaded.save()
#             files_pk.append(uploaded.pk)
#         save_data.delay(files=json.dumps(files_pk))
#     return HttpResponseRedirect(reverse_lazy('home'))


# def get_geo(request):
#     data_list = Geometry.objects.all().order_by('id').last()
#     data = serialize('geojson',
#                      [data_list], geometry_field='geom')
#     print(data)
#     return HttpResponse(data, content_type='application/json')





 
class floodanalysis(TemplateView): 
    template_name = 'floodanalysis.html'

    def get_context_data(request):
        global figure
        figure = folium.Figure()
        global Map
        Map = geemap.Map()
        
        plugins.LocateControl().add_to(Map)
# #Add measure tool 
        plugins.MeasureControl(position='bottomleft', primary_length_unit='meters', secondary_length_unit='miles', primary_area_unit='sqmeters', secondary_area_unit='acres').add_to(Map)
        keserian = ee.FeatureCollection("projects/ee-mosongjrn001/assets/Kiserian_study_area")
        Map.addLayer(keserian,{},"kISERIAN SHAPEFILE")
        Map.center_object(keserian,13)
        buildings = ee.FeatureCollection('GOOGLE/Research/open-buildings/v1/polygons');
        global keserian_buildings
        keserian_buildings=buildings\
        .filter('confidence >= 0.70')\
        .filterBounds(keserian)\
        
        Map.addLayer(keserian_buildings,{'color': 'ff0000'},"ROI Population")
        
        #Creation of heat map

        def func_tbb(buildinds_feature_collection):
            return buildinds_feature_collection.set('google_buildinds',1)

        google_buildings = keserian_buildings.map(func_tbb)

        def heatmap(google_buildings,radius):
            ptImg = google_buildings.reduceToImage(['google_buildinds'],ee.Reducer.first()).unmask(0)
            kernel = ee.Kernel.circle(radius)
            result = ptImg.convolve(kernel)
            return result.updateMask(result.neq(0))

# Adjust the buffering radius
        Buildings_heatmap = heatmap(google_buildings,8)
#Colour Gradient
        gradient = ['green','yellow','red']
        
        
        
        
        
#Conditional classes for popuplation

#Breaking of reclassified imaged into more than one class.
# Rainfall_Amount2=predicted_water_level

        User_Rainfall_Amount=(np.array(Rainfall_Amount1).reshape(1,-1))
        predicted_riverlevel=rain_level_regressor.predict(User_Rainfall_Amount)
        print("Expected water rise will be",predicted_riverlevel)
        
        if predicted_riverlevel>=0 and predicted_riverlevel<=2:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class1,{'palette':flood_palette},"Flood Affected Region (II)")
                        print("The expected water rise will be approximately 2meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=4:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class2,{'palette':flood_palette},"Flood Affected Region (II)")
                        print("The expected water rise will be approximately 4 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=5:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class3,{'palette':flood_palette},"Flood Affected Region (III)")
                        print("The expected water rise will be approximately 5 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=7:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class4,{'palette':flood_palette},"Flood Affected Region (IV)")
                        print("The expected water rise will be approximately 7 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=9:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class5,{'palette':flood_palette},"Flood Affected Region (V)")
                        print("The expected water rise will be approximately 9 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=12:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        
                        Map.addLayer(flood_mask_class6,{'palette':flood_palette},"Flood Affected Region  (VI)'")
                        print("The expected water rise will be approximately 12 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=14:
                plot=gdf1.drop(columns=["state","geom","gid"])
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class7,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 14 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=17:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        
                        Map.addLayer(flood_mask_class8,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 17 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=19:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class9,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 19 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=21:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class10,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 21 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=27:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class11,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 27 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=28:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        
                        Map.addLayer(flood_mask_class12,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 28 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=31:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class13,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 31 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=35:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class14,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 35 meters")
        elif predicted_riverlevel>=0 and predicted_riverlevel<=37:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        Map.addLayer(flood_mask_class15,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 37 meters")

        elif predicted_riverlevel>=0 and predicted_riverlevel<=40:
                for i in range(0,len(gdf1)):
                        html=f"""
        <p>Station Readings:</p>
        <li>location: {gdf1.iloc[i]['location']},</li>
        <li>rainfall: {gdf1.iloc[i]['rainfall']},</li>
        <li>Pred.W.L: {gdf1.iloc[i]['predicted_water_level']},</li>
        <li>temperature: {gdf1.iloc[i]['temperature']},</li>
        <li>Soil Moisture: {gdf1.iloc[i]['soil_moisture']},</li>
        <li>Evaporation: {gdf1.iloc[i]['Evaporation']},</li>
        </p>
        <p>Explore:<a href="https://www.populationu.com/kenya-population">Learn More</a></p>
        
        <p style="margin-top:100px"></p>
        """
                        iframe = folium.IFrame(html=html, width=200, height=200)
                        popup = folium.Popup(iframe, max_width=2650)
                        folium.Marker(
                        location=[gdf1.iloc[i]['latitude'], gdf1.iloc[i]['longitude']],
                        popup=popup,
                        icon=folium.Icon(color="red", icon="info-sign"),
                        ).add_to(Map)
                        
                        Map.addLayer(flood_mask_class16,{'palette':flood_palette},"Flood Affected Region  (VII)")
                        print("The expected water rise will be approximately 40 meters")   
       
        #Add layers to be visualized n the map  
        Map.addLayer(Buildings_heatmap,{'palette':gradient, 'min':0, 'max':0.6},'Built-up Regions')
        
        vis_params = {
                    'min': 1,
                    'max': 100,
                    'palette':['green','yellow','red'],
                }
        colors = vis_params['palette']
        vmin = vis_params['min']
        vmax = vis_params['max']
        Map.add_colorbar(vis_params,label='Population(Google Footprint)')
        legend_dict = {
    'BareLand': 'd6ba61',#1
    'Buildings': '09080c',#
    'Vegetation': '33698b',#
    'Agricultral': 'ff2407',
    'Water Bodies': '00ffff',#
                }
        Map.add_legend(legend_dict=legend_dict,position='topleft')
    
        Map.add_to(figure)
  
        Map.add_child(folium.LayerControl())
        
        figure.render()

        return {"floodanalysis": figure}
