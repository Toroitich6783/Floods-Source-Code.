
from django.db import models
#from django.contrib.gis.db import models this aid in connection to database and activates the pointcharfield instate.

from django.contrib.gis.db import models
from django.db.models import Manager as GeoManager


# Create your models here.

class Post(models.Model):
    title= models.CharField(max_length=300, unique=True)
    content= models.TextField()
    
    def _str_(self):
        return self.title
from django.db import models

class MyModel(models.Model):
    fullname = models.CharField(max_length=200)
    mobile_number = models.IntegerField()
    
weather_statition_CHOICES = (
    ('1','station_19'),
    ('2', 'Komilo'),
    ('3','Torongo'),
    ('4','Loiminage'),
    ('5','Tugumoi'),
    ('6','Dekut Farm'),
    ('7','Nyeri Town station'),
)



class floodreader1(models.Model):
    Station = models.CharField(max_length=20, choices=weather_statition_CHOICES, default='station_19')
    Station1=models.CharField(max_length=200)
    Temperature= models.IntegerField()
    Rainfall=models.IntegerField()
    Time=models.IntegerField()
#additional models
    soilmoisture= models.IntegerField()
    Evaporation=  models.IntegerField()
    
    
#Models for uploading  data
import os
from django.db import models
from django.db.models.signals import post_delete
from django.dispatch import receiver
from django.contrib.gis.db import models
from django.urls import reverse


class UploadedFile(models.Model):
    document = models.FileField(upload_to='shapefile/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def filename(self):
        return os.path.basename(self.document.name)


class Shapefile(models.Model):
    name = models.CharField(max_length=255)

    class Meta:
        default_related_name = 'shapefiles'
        verbose_name = 'shapefile'
        verbose_name_plural = 'shapefiles'

    def __str__(self):
        return self.name

class Geometry(models.Model):
    shapefile = models.ForeignKey(Shapefile, on_delete=models.CASCADE)
    geom = models.GeometryField(srid=4326)

    class Meta:
        default_related_name = 'geometries'
        verbose_name = 'geometry'
        verbose_name_plural = 'geometries'

    def __str__(self):
        return self.geom



@receiver(post_delete, sender=UploadedFile)
def submission_delete(sender, instance, **kwargs):
    instance.document.delete(False)
