from django import forms
from .models import MyModel,floodreader1

class MyForm(forms.ModelForm):
  class Meta:
    model = MyModel
    fields = ["fullname", "mobile_number",]
    labels = {'fullname': "Name", "mobile_number": "Mobile Number",}


class MyForm1(forms.ModelForm):
    class Meta:
        model = floodreader1
        fields = ["Station", "Temperature","Rainfall","soilmoisture","Evaporation","Time",]
        labels = {'Station': "Select Weather Station", "Temperature": "Temperature(°C)","Rainfall":"Rainfall(MM)","soilmoisture":"Soil Moisture","Evaporation":"Evaporation","Time":"Time(hrs)",}
        


# weather_statition_CHOICES= [
#     ('orange', 'Oranges'),
#     ('cantaloupe', 'Cantaloupes'),
#     ('mango', 'Mangoes'),
#     ('honeydew', 'Honeydews'),
#     ]

# class MyForm1(forms.Form):
#       class Meta:
#             model = floodreader1
#             Station= forms.CharField(label='Please select weather station', widget=forms.Select(choices=weather_statition_CHOICES))
#             Temperature= forms.IntegerField()
#             Rainfall=forms.IntegerField()
#             Time=forms.IntegerField()
 