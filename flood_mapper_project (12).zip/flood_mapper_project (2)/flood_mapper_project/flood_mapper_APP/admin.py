from django.contrib import admin
from .models import Post,MyModel,floodreader1
# Register your models here.
class IncidencesAdmin(admin.ModelAdmin):
    list_display =('title','content')
admin.site.register(Post,IncidencesAdmin)


# Register your models here.
class inputs(admin.ModelAdmin):
    list_display =('fullname','mobile_number')
admin.site.register(MyModel,inputs)
# Register your models here.
class floodinputs(admin.ModelAdmin):
    list_display =('Station','Temperature','Rainfall','Time')
admin.site.register(floodreader1,floodinputs)
