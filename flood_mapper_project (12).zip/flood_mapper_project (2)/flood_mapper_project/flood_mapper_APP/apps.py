from django.apps import AppConfig


class FloodMapperAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'flood_mapper_APP'
